-- ============================================================
-- مكشات — مخطط قاعدة البيانات الكامل (Supabase / Postgres)
-- ============================================================
-- طريقة الاستخدام: افتح مشروعك في supabase.com → SQL Editor → New query
-- الصق هذا الملف بالكامل → Run. آمن التشغيل أكثر من مرة (IF NOT EXISTS).

-- ---------- الملفات الشخصية (مرتبطة بحسابات auth.users) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default 'مستخدم جديد',
  is_admin boolean not null default false,
  is_banned boolean not null default false,
  created_at timestamptz not null default now()
);

-- إنشاء صف profile تلقائيًا عند تسجيل أي مستخدم جديد
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', 'مستخدم جديد'));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------- الدول ----------
create table if not exists public.countries (
  code text primary key, -- kw, sa, bh, qa, ae, om, iq
  name_ar text not null,
  name_en text not null,
  lat double precision not null,
  lng double precision not null
);

-- ---------- الطيور ----------
create table if not exists public.birds (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null,
  name_en text not null,
  description text not null default '',
  image_url text, -- رابط صورة حقيقي (خارجي، أو رابط عام من Supabase Storage إن رفعتها هناك)
  season text not null check (season in ('spring', 'autumn')),
  route jsonb not null default '[]', -- [{lat,lng,label}]
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- مواعيد هجرة كل طائر لكل دولة ----------
create table if not exists public.migration_windows (
  id uuid primary key default gen_random_uuid(),
  bird_id uuid not null references public.birds(id) on delete cascade,
  country_code text not null references public.countries(code),
  start_date date not null,
  end_date date not null,
  places text[] not null default '{}',
  unique (bird_id, country_code)
);

-- ---------- المفضلة (لكل مستخدم) ----------
create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  bird_id uuid not null references public.birds(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, bird_id)
);

-- ---------- إعدادات التنبيهات (لكل مستخدم) ----------
create table if not exists public.notification_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  enabled boolean not null default true,
  days_before int not null default 7
);

-- ---------- الرومات ----------
create table if not exists public.rooms (
  id text primary key, -- Room ID المعروض للمستخدم (رقم فريد قصير)
  name text not null,
  description text not null default '',
  host_id uuid not null references auth.users(id) on delete cascade,
  seats_count int not null check (seats_count in (4, 6, 8, 12)),
  is_private boolean not null default false,
  password text,
  locked boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.room_seats (
  room_id text not null references public.rooms(id) on delete cascade,
  seat_index int not null,
  user_id uuid references auth.users(id) on delete set null,
  muted boolean not null default true,
  primary key (room_id, seat_index)
);

create table if not exists public.room_messages (
  id uuid primary key default gen_random_uuid(),
  room_id text not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);

-- ============================================================
-- الصلاحيات (Row Level Security) — المستخدم العادي لا يعدّل الطيور
-- ============================================================
alter table public.profiles enable row level security;
alter table public.countries enable row level security;
alter table public.birds enable row level security;
alter table public.migration_windows enable row level security;
alter table public.favorites enable row level security;
alter table public.notification_settings enable row level security;
alter table public.rooms enable row level security;
alter table public.room_seats enable row level security;
alter table public.room_messages enable row level security;

-- دالة مساعدة: هل المستخدم الحالي أدمن؟
create or replace function public.is_admin()
returns boolean as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$ language sql stable security definer;

-- profiles: كل مستخدم يقرأ/يعدّل ملفه فقط، الأدمن يقرأ ويحظر الجميع
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
  for select using (auth.uid() = id or public.is_admin());
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id or public.is_admin());

-- countries/birds/migration_windows: قراءة عامة للجميع، تعديل للأدمن فقط
drop policy if exists "countries_read_all" on public.countries;
create policy "countries_read_all" on public.countries for select using (true);
drop policy if exists "countries_write_admin" on public.countries;
create policy "countries_write_admin" on public.countries for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "birds_read_all" on public.birds;
create policy "birds_read_all" on public.birds for select using (true);
drop policy if exists "birds_write_admin" on public.birds;
create policy "birds_write_admin" on public.birds for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "windows_read_all" on public.migration_windows;
create policy "windows_read_all" on public.migration_windows for select using (true);
drop policy if exists "windows_write_admin" on public.migration_windows;
create policy "windows_write_admin" on public.migration_windows for all using (public.is_admin()) with check (public.is_admin());

-- favorites: كل مستخدم يرى ويعدّل مفضلته فقط
drop policy if exists "favorites_own" on public.favorites;
create policy "favorites_own" on public.favorites for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- notification_settings: كل مستخدم يرى ويعدّل إعداداته فقط
drop policy if exists "notif_own" on public.notification_settings;
create policy "notif_own" on public.notification_settings for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- rooms: قراءة عامة (لظهورها في القائمة)، الإنشاء لأي مستخدم مسجّل، التعديل/الحذف للمضيف أو الأدمن
drop policy if exists "rooms_read_all" on public.rooms;
create policy "rooms_read_all" on public.rooms for select using (true);
drop policy if exists "rooms_insert_auth" on public.rooms;
create policy "rooms_insert_auth" on public.rooms for insert with check (auth.uid() = host_id);
drop policy if exists "rooms_update_host_admin" on public.rooms;
create policy "rooms_update_host_admin" on public.rooms for update using (auth.uid() = host_id or public.is_admin());
drop policy if exists "rooms_delete_host_admin" on public.rooms;
create policy "rooms_delete_host_admin" on public.rooms for delete using (auth.uid() = host_id or public.is_admin());

-- room_seats: قراءة عامة، والتعديل محكوم بدقة:
--   INSERT مسموح فقط لمضيف الغرفة (عند إنشائها)
--   UPDATE مسموح لصاحب المقعد نفسه (كتم/فتح مايك)، أو لأي مستخدم يحجز مقعدًا فارغًا (انضمام)،
--   أو للمضيف/الأدمن (إدارة أي مقعد)
drop policy if exists "seats_read_all" on public.room_seats;
create policy "seats_read_all" on public.room_seats for select using (true);

drop policy if exists "seats_write_own_or_host" on public.room_seats;

drop policy if exists "seats_insert_host" on public.room_seats;
create policy "seats_insert_host" on public.room_seats for insert
  with check (exists (select 1 from public.rooms r where r.id = room_id and r.host_id = auth.uid()));

drop policy if exists "seats_update_join_or_own_or_host" on public.room_seats;
create policy "seats_update_join_or_own_or_host" on public.room_seats for update
  using (
    user_id is null
    or auth.uid() = user_id
    or exists (select 1 from public.rooms r where r.id = room_id and r.host_id = auth.uid())
    or public.is_admin()
  )
  with check (
    user_id is null
    or auth.uid() = user_id
    or exists (select 1 from public.rooms r where r.id = room_id and r.host_id = auth.uid())
    or public.is_admin()
  );

-- room_messages: أعضاء الروم فقط يقرؤون ويرسلون
drop policy if exists "messages_read_all" on public.room_messages;
create policy "messages_read_all" on public.room_messages for select using (true);
drop policy if exists "messages_insert_own" on public.room_messages;
create policy "messages_insert_own" on public.room_messages for insert with check (auth.uid() = user_id);

-- ============================================================
-- تفعيل Realtime على جداول الرومات والشات (للمرحلة القادمة)
-- ============================================================
alter publication supabase_realtime add table public.room_messages;
alter publication supabase_realtime add table public.room_seats;
alter publication supabase_realtime add table public.rooms;

-- ============================================================
-- بيانات الدول الأساسية (ثابتة، لا تتغيّر)
-- ============================================================
insert into public.countries (code, name_ar, name_en, lat, lng) values
  ('kw', 'الكويت', 'Kuwait', 29.3759, 47.9774),
  ('sa', 'السعودية', 'Saudi Arabia', 23.8859, 45.0792),
  ('bh', 'البحرين', 'Bahrain', 26.0667, 50.5577),
  ('qa', 'قطر', 'Qatar', 25.3548, 51.1839),
  ('ae', 'الإمارات', 'United Arab Emirates', 23.4241, 53.8478),
  ('om', 'عمان', 'Oman', 21.4735, 55.9754),
  ('iq', 'العراق', 'Iraq', 33.2232, 43.6793)
on conflict (code) do nothing;
