// Supabase Edge Function: livekit-token
// -----------------------------------------------------------
// الغرض الوحيد لهذه الدالة: توليد "رمز دخول" (Access Token) مؤقت وآمن لصوت LiveKit،
// دون أن يغادر مفتاح LIVEKIT_API_SECRET السري السيرفر أبدًا (لا يظهر في أي كود عميل).
//
// تُنفَّذ على سيرفرات Supabase (Deno)، وتتحقق أولًا أن الطالب مستخدم مسجّل دخول حقيقي
// وأنه بالفعل يشغل مقعدًا في الغرفة المطلوبة (عبر قاعدة البيانات نفسها) قبل إصدار أي رمز.

import { createClient } from "npm:@supabase/supabase-js@2";
import { AccessToken } from "npm:livekit-server-sdk@2";

const LIVEKIT_API_KEY = Deno.env.get("LIVEKIT_API_KEY")!;
const LIVEKIT_API_SECRET = Deno.env.get("LIVEKIT_API_SECRET")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    if (!LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
      return new Response(JSON.stringify({ error: "LiveKit غير مُهيّأ على السيرفر بعد." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization") ?? "";
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const {
      data: { user },
      error: userErr,
    } = await supabase.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "يجب تسجيل الدخول أولًا." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { roomId } = await req.json();
    if (!roomId) {
      return new Response(JSON.stringify({ error: "roomId مطلوب." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // تحقّق فعلي: هل هذا المستخدم يشغل بالفعل مقعدًا في هذه الغرفة؟ (يمنع أي شخص من
    // الحصول على رمز صوت لغرفة لم ينضم إليها عبر التطبيق)
    const { data: seat } = await supabase
      .from("room_seats")
      .select("seat_index")
      .eq("room_id", roomId)
      .eq("user_id", user.id)
      .maybeSingle();
    if (!seat) {
      return new Response(JSON.stringify({ error: "لست عضوًا في هذه الغرفة." }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profile } = await supabase.from("profiles").select("name").eq("id", user.id).maybeSingle();

    const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity: user.id,
      name: profile?.name ?? "مستخدم",
      ttl: "6h",
    });
    at.addGrant({ room: roomId, roomJoin: true, canPublish: true, canSubscribe: true });

    const token = await at.toJwt();

    return new Response(JSON.stringify({ token }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "خطأ غير متوقع" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
