import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { ErrorBoundary } from "./components/ErrorBoundary";
import "./index.css";

// أول سطر تنفيذي فعليًا في كامل حزمة التطبيق — مجرد وصوله لهذه النقطة يثبت
// أن ملف JavaScript الرئيسي حُمِّل ونُفِّذ بنجاح (يُلغي رسالة التشخيص في index.html)
(window as unknown as Record<string, boolean>).__MAKASHAT_BOOT_OK__ = true;

// تسجيل تشخيصي عام: أي خطأ JS غير مُمسَك، أو أي Promise مرفوضة بلا catch،
// تظهر في Logcat/chrome://inspect بادئة واضحة — مهم جدًا لتشخيص أي مشكلة
// مستقبلية داخل WebView حيث لا توجد أدوات مطوّر ظاهرة افتراضيًا.
window.addEventListener("error", (e) => {
  console.error("[مكشات] خطأ عام غير مُمسَك:", e.error ?? e.message);
});
window.addEventListener("unhandledrejection", (e) => {
  console.error("[مكشات] Promise مرفوضة بلا معالجة:", e.reason);
});

const rootEl = document.getElementById("root");

if (!rootEl) {
  // احتمال ضعيف جدًا (يعني index.html نفسه تالف)، لكن نعرض رسالة بدل صفحة بيضاء تمامًا
  document.body.innerHTML =
    '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0a0c12;color:#fff;font-family:system-ui;direction:rtl">تعذّر تحميل التطبيق (root غير موجود)</div>';
} else {
  try {
    ReactDOM.createRoot(rootEl).render(
      <React.StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </React.StrictMode>
    );
  } catch (e) {
    // أي استثناء متزامن أثناء أول رندر (نادر لكن ممكن) — لا نترك الشاشة بيضاء
    console.error("[مكشات] فشل الإقلاع الأولي:", e);
    rootEl.innerHTML =
      '<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#0a0c12;color:#fff;font-family:system-ui;direction:rtl;padding:24px;text-align:center;box-sizing:border-box;"><div style="font-size:32px;margin-bottom:12px;">⚠️</div><div>تعذّر تشغيل التطبيق</div><pre style="font-size:10px;color:#5f6b7a;direction:ltr;margin-top:16px;white-space:pre-wrap;">' +
      String(e instanceof Error ? e.message : e) +
      "</pre></div>";
  }
}
