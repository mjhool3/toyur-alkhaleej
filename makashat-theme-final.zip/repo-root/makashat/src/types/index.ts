export type CountryCode =
  | "kw" // الكويت
  | "sa" // السعودية
  | "bh" // البحرين
  | "qa" // قطر
  | "ae" // الإمارات
  | "om" // عمان
  | "iq"; // العراق

export interface Country {
  code: CountryCode;
  name_ar: string;
  name_en: string;
  lat: number;
  lng: number;
}

export type MigrationStatus = "upcoming" | "active" | "ended";
export type MigrationSeason = "spring" | "autumn";

export interface MigrationWindow {
  country: CountryCode;
  start_date: string; // ISO date — تُدار من لوحة التحكم
  end_date: string;
  places: string[]; // أماكن مشاهدة حقيقية داخل الدولة
}

export interface Bird {
  id: string;
  name_ar: string;
  name_en: string;
  description: string;
  image_url: string | null; // من Supabase Storage — لا روابط مؤقتة
  season: MigrationSeason;
  route: { lat: number; lng: number; label: string }[]; // مسار الهجرة الحقيقي
  windows: MigrationWindow[]; // موعد الهجرة لكل دولة — قابل للتعديل من لوحة التحكم
}

export const COUNTRIES: Country[] = [
  { code: "kw", name_ar: "الكويت", name_en: "Kuwait", lat: 29.3759, lng: 47.9774 },
  { code: "sa", name_ar: "السعودية", name_en: "Saudi Arabia", lat: 23.8859, lng: 45.0792 },
  { code: "bh", name_ar: "البحرين", name_en: "Bahrain", lat: 26.0667, lng: 50.5577 },
  { code: "qa", name_ar: "قطر", name_en: "Qatar", lat: 25.3548, lng: 51.1839 },
  { code: "ae", name_ar: "الإمارات", name_en: "United Arab Emirates", lat: 23.4241, lng: 53.8478 },
  { code: "om", name_ar: "عمان", name_en: "Oman", lat: 21.4735, lng: 55.9754 },
  { code: "iq", name_ar: "العراق", name_en: "Iraq", lat: 33.2232, lng: 43.6793 },
];
