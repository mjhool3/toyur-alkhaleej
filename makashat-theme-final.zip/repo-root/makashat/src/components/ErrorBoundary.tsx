import { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle } from "lucide-react";

interface Props {
  children: ReactNode;
}
interface State {
  error: Error | null;
}

/**
 * بدون هذا المكوّن، أي خطأ غير متوقع أثناء الرندر (حتى لو بسيطًا في مكوّن واحد)
 * كان يؤدي في React 18 إلى إلغاء تركيب الشجرة بالكامل → شاشة بيضاء صامتة تمامًا،
 * خصوصًا داخل Capacitor WebView حيث لا توجد أدوات مطوّر ظاهرة لرؤية الخطأ.
 * هذا المكوّن يمسك الخطأ ويعرض واجهة عربية واضحة بدل الفراغ الكامل.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // يظهر في Logcat عند توصيل الهاتف بـ chrome://inspect — أهم أداة تشخيص فعلية على Android
    console.error("[مكشات] خطأ غير متوقع:", error, info.componentStack);
  }

  handleReload = () => {
    this.setState({ error: null });
    window.location.hash = "#/";
    window.location.reload();
  };

  render() {
    if (this.state.error) {
      return (
        <div
          dir="rtl"
          style={{
            minHeight: "100vh",
            background: "#0a0c12",
            color: "#fff",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
            textAlign: "center",
            fontFamily: "system-ui, sans-serif",
          }}
        >
          <div style={{ marginBottom: 12, width: 56, height: 56, borderRadius: "999px", background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", color: "#d4af37" }}>
            <AlertTriangle size={26} strokeWidth={1.75} />
          </div>
          <p style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>حدث خطأ غير متوقع</p>
          <p style={{ fontSize: 13, color: "#b0b6c1", marginBottom: 20, maxWidth: 320 }}>
            واجه التطبيق مشكلة أثناء التحميل. جرّب إعادة المحاولة، وإذا تكررت المشكلة أخبرنا
            برسالة الخطأ التالية.
          </p>
          <button
            onClick={this.handleReload}
            style={{
              background: "#d4af37",
              color: "#000",
              fontWeight: 700,
              padding: "10px 24px",
              borderRadius: 999,
              border: "none",
            }}
          >
            إعادة المحاولة
          </button>
          <pre
            style={{
              marginTop: 20,
              fontSize: 10,
              color: "#5f6b7a",
              maxWidth: "100%",
              overflow: "auto",
              direction: "ltr",
              textAlign: "left",
            }}
          >
            {String(this.state.error?.message ?? this.state.error)}
          </pre>
        </div>
      );
    }
    return this.props.children;
  }
}
