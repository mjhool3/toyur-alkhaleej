import { useOnlineStatus } from "../hooks/useOnlineStatus";

export function OfflineBanner() {
  const online = useOnlineStatus();
  if (online) return null;
  return (
    <div dir="rtl" className="fixed top-0 inset-x-0 z-[90] bg-yellow-600/95 text-black text-xs font-semibold text-center py-2">
      تحقق من اتصال الإنترنت وحاول مرة أخرى.
    </div>
  );
}
