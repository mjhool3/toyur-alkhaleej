import { HashRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ToastProvider } from "./contexts/ToastContext";
import { AuthProvider } from "./contexts/AuthContext";
import { BottomNav } from "./components/BottomNav";
import { OfflineBanner } from "./components/OfflineBanner";
import Home from "./pages/Home";
import Migration from "./pages/Migration";
import BirdsDashboard from "./pages/BirdsDashboard";
import Birds from "./pages/Birds";
import BirdDetail from "./pages/BirdDetail";
import MapPage from "./pages/MapPage";
import Rooms from "./pages/Rooms";
import RoomDetail from "./pages/RoomDetail";
import Favorites from "./pages/Favorites";
import Notifications from "./pages/Notifications";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Admin from "./pages/Admin";
import Login from "./pages/Login";

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
      <AuthProvider>
      <HashRouter>
        <div className="min-h-full">
          <OfflineBanner />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/migration" element={<Migration />} />
            <Route path="/birds" element={<BirdsDashboard />} />
            <Route path="/birds/all" element={<Birds />} />
            <Route path="/birds/:id" element={<BirdDetail />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/rooms" element={<Rooms />} />
            <Route path="/rooms/:id" element={<RoomDetail />} />
            <Route path="/favorites" element={<Favorites />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/login" element={<Login />} />
          </Routes>
          <BottomNav />
        </div>
      </HashRouter>
      </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
