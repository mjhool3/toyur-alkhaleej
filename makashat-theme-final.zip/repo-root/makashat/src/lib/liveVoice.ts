import type { Room as LKRoom, RemoteTrack, RemoteParticipant, ConnectionState } from "livekit-client";
import { supabase, isSupabaseConfigured } from "./supabase";

const LIVEKIT_URL = (import.meta.env.VITE_LIVEKIT_URL as string | undefined) || "";

export const isVoiceConfigured = Boolean(isSupabaseConfigured && LIVEKIT_URL);

export type VoiceConnectionState = "idle" | "connecting" | "connected" | "reconnecting" | "disconnected" | "error";

interface VoiceCallbacks {
  onStateChange?: (state: VoiceConnectionState) => void;
  onSpeakingChange?: (speakingUserIds: Set<string>) => void;
  onError?: (message: string) => void;
}

/**
 * جلسة صوت حقيقية واحدة داخل روم معيّن. تُدار من صفحة الروم مباشرة:
 * connect() عند دخول الروم، setMicEnabled() عند فتح/كتم المايك، disconnect() عند الخروج.
 * مكتبة livekit-client بأكملها تُحمَّل ديناميكيًا داخل connect() فقط — لا تدخل الحزمة
 * الأساسية للتطبيق إطلاقًا، ولا يمكن أن تسبب أي مشكلة تحميل قبل استخدامها فعليًا.
 */
export class VoiceSession {
  private room: LKRoom | null = null;
  private callbacks: VoiceCallbacks;
  private audioEls = new Map<string, HTMLAudioElement>();

  constructor(callbacks: VoiceCallbacks = {}) {
    this.callbacks = callbacks;
  }

  async connect(roomId: string): Promise<void> {
    if (!isVoiceConfigured) {
      throw new Error("الصوت الحقيقي غير مُفعّل بعد (يحتاج ربط LiveKit). راجع README.");
    }
    this.callbacks.onStateChange?.("connecting");

    let livekit: typeof import("livekit-client");
    try {
      livekit = await import("livekit-client");
    } catch {
      const msg = "تعذّر تحميل مكوّن الصوت (تحقق من الاتصال بالإنترنت).";
      this.callbacks.onStateChange?.("error");
      this.callbacks.onError?.(msg);
      throw new Error(msg);
    }
    const { Room, RoomEvent, Track, ConnectionState: CS } = livekit;

    const { data, error } = await supabase.functions.invoke<{ token?: string; error?: string }>("livekit-token", {
      body: { roomId },
    });
    if (error || !data?.token) {
      const msg = data?.error || error?.message || "تعذّر الحصول على تصريح الصوت.";
      this.callbacks.onStateChange?.("error");
      this.callbacks.onError?.(msg);
      throw new Error(msg);
    }

    const room = new Room({ adaptiveStream: true, dynacast: true });
    this.room = room;

    room.on(RoomEvent.ConnectionStateChanged, (state: ConnectionState) => {
      if (state === CS.Connected) this.callbacks.onStateChange?.("connected");
      else if (state === CS.Reconnecting) this.callbacks.onStateChange?.("reconnecting");
      else if (state === CS.Disconnected) this.callbacks.onStateChange?.("disconnected");
    });

    room.on(RoomEvent.TrackSubscribed, (track: RemoteTrack, _pub, participant: RemoteParticipant) => {
      if (track.kind !== Track.Kind.Audio) return;
      const el = track.attach();
      el.autoplay = true;
      this.audioEls.set(participant.identity, el as HTMLAudioElement);
      document.body.appendChild(el);
    });

    room.on(RoomEvent.TrackUnsubscribed, (track: RemoteTrack) => {
      track.detach().forEach((el) => el.remove());
    });

    room.on(RoomEvent.ActiveSpeakersChanged, (speakers: RemoteParticipant[]) => {
      this.callbacks.onSpeakingChange?.(new Set(speakers.map((p) => p.identity)));
    });

    room.on(RoomEvent.Disconnected, () => {
      this.callbacks.onStateChange?.("disconnected");
    });

    try {
      await room.connect(LIVEKIT_URL, data.token);
      this.callbacks.onStateChange?.("connected");
    } catch (e) {
      this.callbacks.onStateChange?.("error");
      const msg = e instanceof Error ? e.message : "تعذّر الاتصال بخدمة الصوت.";
      this.callbacks.onError?.(msg);
      throw new Error(msg);
    }
  }

  /** فتح/كتم المايك فعليًا — يطلب صلاحية الميكروفون من المتصفح إن لزم */
  async setMicEnabled(enabled: boolean): Promise<void> {
    if (!this.room) return;
    try {
      await this.room.localParticipant.setMicrophoneEnabled(enabled);
    } catch (e) {
      const msg =
        e instanceof Error && e.name === "NotAllowedError"
          ? "تم رفض صلاحية الميكروفون. فعّلها من إعدادات المتصفح/الجهاز."
          : "تعذّر الوصول إلى الميكروفون.";
      this.callbacks.onError?.(msg);
      throw new Error(msg);
    }
  }

  disconnect(): void {
    this.audioEls.forEach((el) => el.remove());
    this.audioEls.clear();
    this.room?.disconnect();
    this.room = null;
  }
}
