/**
 * بعض إصدارات Android WebView القديمة لا تدعم crypto.randomUUID() (يتطلب Chrome 92+
 * ضمن سياق آمن). استدعاؤه مباشرة على جهاز لا يدعمه يرمي استثناءً، وبما أنه لا يوجد
 * Error Boundary وقتها سابقًا كان يؤدي لشاشة بيضاء كاملة. هذه الدالة تتحقق أولًا،
 * وتستخدم بديلًا آمنًا 100% إن لزم.
 */
export function safeId(): string {
  try {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
  } catch {
    // تجاهل ومتابعة إلى البديل
  }
  // بديل: يكفي تمامًا كمعرّف فريد محليًا (ليس مطلوبًا أن يكون UUID قياسيًا هنا)
  return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
}
