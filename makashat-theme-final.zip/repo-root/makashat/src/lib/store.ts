/**
 * طبقة البيانات المحلية (Local Data Layer)
 * ------------------------------------------------
 * هذا "الباك-إند المحلي" يحفظ كل شيء فعليًا في localStorage على جهاز المستخدم،
 * ويُستخدم مؤقتًا فقط لأن مشروع Supabase لم يُربط بعد (لا توجد مفاتيح في .env).
 *
 * كل دالة هنا مكتوبة بنفس "شكل" ما سيكون عليه استدعاء Supabase لاحقًا
 * (async، ترجع Promise) حتى يكون استبدال الجسم الداخلي فقط (بدون تغيير
 * الصفحات التي تستدعيها) هو كل ما يلزم عند تفعيل المفاتيح الحقيقية.
 *
 * إذا تم ضبط مفاتيح Supabase مستقبلًا، يجب استبدال هذا الملف تدريجيًا
 * باستدعاءات supabase.from(...) الحقيقية بدل localStorage.
 */
import { Bird, CountryCode } from "../types";
import { SEED_BIRDS } from "./seedBirds";
import { isSupabaseConfigured, supabase } from "./supabase";
import { safeId } from "./safeId";
import {
  sbListBirds,
  sbGetBird,
  sbUpsertBird,
  sbDeleteBird,
  sbGetFavoriteIds,
  sbToggleFavorite,
  sbGetNotificationSettings,
  sbSetNotificationSettings,
  sbGetProfile,
  sbUpdateProfileName,
  sbListRooms,
  sbGetRoom,
  sbCreateRoom,
  sbJoinRoom,
  sbLeaveRoom,
  sbSetSeatMuted,
  sbDeleteRoom,
  sbGetRoomMessages,
  sbSendRoomMessage,
  sbSubscribeToRoom,
  sbSubscribeToRoomsList,
} from "./supabaseData";

// يُستخدم داخليًا فقط لمعرفة هوية المستخدم المسجّل حاليًا عبر Supabase (إن وُجد)
async function currentUserId(): Promise<string | null> {
  if (!isSupabaseConfigured) return null;
  const { data } = await supabase.auth.getSession();
  return data.session?.user?.id ?? null;
}

const KEYS = {
  birds: "makashat.birds.v1",
  favorites: "makashat.favorites.v1",
  rooms: "makashat.rooms.v1",
  messages: (roomId: string) => `makashat.room_messages.${roomId}.v1`,
  notifSettings: "makashat.notif_settings.v1",
  profile: "makashat.profile.v1",
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // تجاهل بأمان (مثلًا وضع تصفح خاص أو مساحة ممتلئة) بدل تعطيل التطبيق بالكامل
  }
}

// تأخير بسيط اختياري لمحاكاة زمن شبكة واقعي في حالات التحميل (Loading states)
const settle = <T,>(v: T) => new Promise<T>((resolve) => setTimeout(() => resolve(v), 120));

export { isSupabaseConfigured };

// ---------------- الطيور ----------------
export async function listBirds(): Promise<Bird[]> {
  if (isSupabaseConfigured) return sbListBirds();
  const stored = read<Bird[] | null>(KEYS.birds, null);
  if (stored) return settle(stored);
  const seeded = SEED_BIRDS.map(({ is_seed_placeholder, ...b }) => b);
  write(KEYS.birds, seeded);
  return settle(seeded);
}

export async function getBird(id: string): Promise<Bird | null> {
  if (isSupabaseConfigured) return sbGetBird(id);
  const birds = await listBirds();
  return birds.find((b) => b.id === id) ?? null;
}

export async function upsertBird(bird: Bird): Promise<void> {
  if (isSupabaseConfigured) return sbUpsertBird(bird);
  const birds = await listBirds();
  const idx = birds.findIndex((b) => b.id === bird.id);
  if (idx >= 0) birds[idx] = bird;
  else birds.push(bird);
  write(KEYS.birds, birds);
}

export async function deleteBird(id: string): Promise<void> {
  if (isSupabaseConfigured) return sbDeleteBird(id);
  const birds = await listBirds();
  write(KEYS.birds, birds.filter((b) => b.id !== id));
}

// ---------------- المفضلة ----------------
export async function getFavoriteIds(): Promise<string[]> {
  const uid = await currentUserId();
  if (uid) return sbGetFavoriteIds(uid);
  return settle(read<string[]>(KEYS.favorites, []));
}

export async function toggleFavorite(birdId: string): Promise<string[]> {
  const uid = await currentUserId();
  if (uid) return sbToggleFavorite(uid, birdId);
  const current = read<string[]>(KEYS.favorites, []);
  const next = current.includes(birdId)
    ? current.filter((id) => id !== birdId)
    : [...current, birdId];
  write(KEYS.favorites, next);
  return settle(next);
}

// ---------------- الرومات ----------------
export interface RoomSeat {
  index: number;
  userId: string | null;
  userName: string | null;
  muted: boolean;
}

export interface Room {
  id: string;
  name: string;
  description: string;
  hostName: string;
  seatsCount: 4 | 6 | 8 | 12;
  isPrivate: boolean;
  password: string | null;
  locked: boolean;
  createdAt: string;
  seats: RoomSeat[];
}

function makeLocalRoomId(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function emptySeats(count: number): RoomSeat[] {
  return Array.from({ length: count }, (_, i) => ({ index: i, userId: null, userName: null, muted: true }));
}

export async function listRooms(): Promise<Room[]> {
  if (isSupabaseConfigured) return sbListRooms();
  return settle(read<Room[]>(KEYS.rooms, []));
}

export async function getRoom(id: string): Promise<Room | null> {
  if (isSupabaseConfigured) return sbGetRoom(id);
  const rooms = read<Room[]>(KEYS.rooms, []);
  return settle(rooms.find((r) => r.id === id) ?? null);
}

export async function createRoom(input: {
  name: string;
  description: string;
  hostName: string;
  seatsCount: 4 | 6 | 8 | 12;
  isPrivate: boolean;
  password: string | null;
}): Promise<Room> {
  if (isSupabaseConfigured) {
    const uid = await currentUserId();
    if (!uid) throw new Error("يجب تسجيل الدخول أولًا لإنشاء غرفة.");
    return sbCreateRoom(uid, input);
  }
  const rooms = read<Room[]>(KEYS.rooms, []);
  const room: Room = {
    id: makeLocalRoomId(),
    name: input.name,
    description: input.description,
    hostName: input.hostName,
    seatsCount: input.seatsCount,
    isPrivate: input.isPrivate,
    password: input.password,
    locked: false,
    createdAt: new Date().toISOString(),
    seats: emptySeats(input.seatsCount),
  };
  // المضيف يجلس تلقائيًا في المقعد الأول
  room.seats[0] = { index: 0, userId: "local-user", userName: input.hostName, muted: true };
  rooms.push(room);
  write(KEYS.rooms, rooms);
  return settle(room);
}

export async function joinRoom(roomId: string, userName: string): Promise<Room | null> {
  if (isSupabaseConfigured) {
    const uid = await currentUserId();
    if (!uid) throw new Error("يجب تسجيل الدخول أولًا للانضمام إلى الغرفة.");
    return sbJoinRoom(roomId, uid);
  }
  const rooms = read<Room[]>(KEYS.rooms, []);
  const room = rooms.find((r) => r.id === roomId);
  if (!room) return null;
  const alreadyIn = room.seats.some((s) => s.userId === "local-user");
  if (!alreadyIn) {
    const freeSeat = room.seats.find((s) => s.userId === null);
    if (freeSeat) {
      freeSeat.userId = "local-user";
      freeSeat.userName = userName;
      freeSeat.muted = true;
    }
  }
  write(KEYS.rooms, rooms);
  return settle(room);
}

export async function leaveRoom(roomId: string): Promise<void> {
  if (isSupabaseConfigured) {
    const uid = await currentUserId();
    if (uid) await sbLeaveRoom(roomId, uid);
    return;
  }
  const rooms = read<Room[]>(KEYS.rooms, []);
  const room = rooms.find((r) => r.id === roomId);
  if (room) {
    const seat = room.seats.find((s) => s.userId === "local-user");
    if (seat) {
      seat.userId = null;
      seat.userName = null;
      seat.muted = true;
    }
  }
  write(KEYS.rooms, rooms);
}

export async function setSeatMuted(roomId: string, muted: boolean): Promise<void> {
  if (isSupabaseConfigured) {
    const uid = await currentUserId();
    if (uid) await sbSetSeatMuted(roomId, uid, muted);
    return;
  }
  const rooms = read<Room[]>(KEYS.rooms, []);
  const room = rooms.find((r) => r.id === roomId);
  const seat = room?.seats.find((s) => s.userId === "local-user");
  if (seat) seat.muted = muted;
  write(KEYS.rooms, rooms);
}

export async function deleteRoom(roomId: string): Promise<void> {
  if (isSupabaseConfigured) return sbDeleteRoom(roomId);
  const rooms = read<Room[]>(KEYS.rooms, []);
  write(KEYS.rooms, rooms.filter((r) => r.id !== roomId));
}

// اشتراك حي حقيقي بتغيّرات الغرفة (مقاعد/رسائل) — يعمل فقط عند تفعيل Supabase؛
// محليًا لا يوجد بث بين الأجهزة أصلًا، فتُرجع دالة إيقاف فارغة بأمان
export function subscribeToRoom(roomId: string, onChange: () => void): () => void {
  if (isSupabaseConfigured) return sbSubscribeToRoom(roomId, onChange);
  return () => {};
}

export function subscribeToRoomsList(onChange: () => void): () => void {
  if (isSupabaseConfigured) return sbSubscribeToRoomsList(onChange);
  return () => {};
}

// يُستخدم في صفحة الروم لتحديد "مقعدي أنا" بشكل موحّد بين الوضعين
export async function getMySeatId(): Promise<string> {
  const uid = await currentUserId();
  return uid ?? "local-user";
}

// ---------------- شات الروم ----------------
export interface RoomMessage {
  id: string;
  userName: string;
  text: string;
  time: string;
}

export async function getRoomMessages(roomId: string): Promise<RoomMessage[]> {
  if (isSupabaseConfigured) return sbGetRoomMessages(roomId);
  return settle(read<RoomMessage[]>(KEYS.messages(roomId), []));
}

export async function sendRoomMessage(roomId: string, userName: string, text: string): Promise<RoomMessage[]> {
  if (isSupabaseConfigured) {
    const uid = await currentUserId();
    if (!uid) throw new Error("يجب تسجيل الدخول أولًا لإرسال رسالة.");
    await sbSendRoomMessage(roomId, uid, text);
    return sbGetRoomMessages(roomId);
  }
  const list = read<RoomMessage[]>(KEYS.messages(roomId), []);
  list.push({ id: safeId(), userName, text, time: new Date().toISOString() });
  write(KEYS.messages(roomId), list);
  return settle(list);
}

// ---------------- إعدادات التنبيهات ----------------
export interface NotificationSettings {
  enabled: boolean;
  daysBefore: number;
}

export async function getNotificationSettings(): Promise<NotificationSettings> {
  const uid = await currentUserId();
  if (uid) return sbGetNotificationSettings(uid);
  return settle(read<NotificationSettings>(KEYS.notifSettings, { enabled: true, daysBefore: 7 }));
}

export async function setNotificationSettings(s: NotificationSettings): Promise<void> {
  const uid = await currentUserId();
  if (uid) return sbSetNotificationSettings(uid, s);
  write(KEYS.notifSettings, s);
}

// ---------------- الملف الشخصي (ضيف محلي إلى حين تفعيل تسجيل الدخول) ----------------
export interface LocalProfile {
  name: string;
  userId: string;
}

export async function getProfile(): Promise<LocalProfile> {
  const uid = await currentUserId();
  if (uid) return sbGetProfile(uid);

  let profile = read<LocalProfile | null>(KEYS.profile, null);
  if (!profile) {
    profile = { name: "زائر", userId: "G-" + Math.floor(100000 + Math.random() * 900000) };
    write(KEYS.profile, profile);
  }
  return settle(profile);
}

export async function updateProfile(p: LocalProfile): Promise<void> {
  const uid = await currentUserId();
  if (uid) {
    await sbUpdateProfileName(uid, p.name);
    return;
  }
  write(KEYS.profile, p);
}

export function countryOf(code: CountryCode) {
  return code;
}
