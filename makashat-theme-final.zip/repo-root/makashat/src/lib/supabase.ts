import { createClient, SupabaseClient } from "@supabase/supabase-js";

const rawUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const rawAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim();

// createClient() يستدعي داخليًا "new URL(...)" للتحقق من صحة الرابط — لو كانت القيمة
// الموضوعة في .env بها أي خطأ إملائي (بروتوكول ناقص، مسافة، ...) فهذا يرمي استثناءً
// *فوريًا وقت تحميل الوحدة*، أي قبل أن يبدأ React بالعمل أصلًا — وهذا استثناء لا يستطيع
// أي Error Boundary داخل React أن يمسكه أبدًا (لأنه يحدث قبل وجود أي شجرة React لتمسكه)،
// وينتج عنه شاشة بيضاء صامتة تمامًا. لذلك: تحقق صريح من صحة الرابط أولًا، مع try/catch
// حول الإنشاء نفسه، والرجوع دائمًا لعميل placeholder آمن بدل رمي أي استثناء.
function isValidUrl(value: string | undefined): value is string {
  if (!value) return false;
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

const hasValidConfig = isValidUrl(rawUrl) && Boolean(rawAnonKey);

if (!hasValidConfig) {
  if (rawUrl || rawAnonKey) {
    console.warn(
      "[مكشات] قيم Supabase موجودة في .env لكنها غير صالحة (تحقق من VITE_SUPABASE_URL خصوصًا). سيتابع التطبيق بالبيانات المحلية."
    );
  } else {
    console.warn(
      "[مكشات] لم يتم ضبط مفاتيح Supabase بعد. أضف VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في ملف .env"
    );
  }
}

function createSafeClient(): SupabaseClient {
  try {
    if (hasValidConfig) {
      return createClient(rawUrl!, rawAnonKey!);
    }
  } catch (e) {
    console.error("[مكشات] فشل إنشاء عميل Supabase، سيتم استخدام عميل احتياطي آمن:", e);
  }
  // عميل احتياطي دائمًا صالح الإنشاء (رابط وهمي لكنه well-formed) — لا يرمي أبدًا
  return createClient("https://placeholder.supabase.co", "placeholder-anon-key");
}

export const supabase = createSafeClient();

// تُستخدم في باقي المشروع لمعرفة ما إذا كان يجب الاعتماد على Supabase الحقيقي
// أو الرجوع مؤقتًا لطبقة البيانات المحلية (src/lib/store.ts)
export const isSupabaseConfigured = hasValidConfig;
