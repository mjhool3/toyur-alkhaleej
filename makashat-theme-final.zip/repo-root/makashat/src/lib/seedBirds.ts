import { Bird } from "../types";

/**
 * ⚠️ بيانات بذرية (Seed) فقط لتشغيل الواجهة وعرض التصميم أثناء التطوير.
 * التواريخ والمسارات هنا "أمثلة توضيحية غير موثّقة علميًا" وليست بيانات هجرة حقيقية.
 * يجب استبدالها من لوحة التحكم (Admin Dashboard) ببيانات حقيقية موثوقة قبل النشر،
 * تمامًا كما طلب صاحب المشروع في التعليمات (لا تُعرض بيانات تجريبية كأنها حقيقية).
 * كل حقل قابل للتعديل الكامل من /admin بمجرد ربط Supabase.
 */
export const SEED_BIRDS: (Bird & { is_seed_placeholder: true })[] = [
  {
    id: "seed-1",
    name_ar: "القطقان",
    name_en: "Example Migratory Bird 1",
    description: "بيانات مثال — يرجى استبدالها من لوحة التحكم ببيانات موثقة.",
    image_url: null,
    season: "autumn",
    route: [
      { lat: 33.2232, lng: 43.6793, label: "العراق" },
      { lat: 29.3759, lng: 47.9774, label: "الكويت" },
    ],
    windows: [
      { country: "kw", start_date: "2026-01-02", end_date: "2026-01-20", places: ["يُحدَّد من لوحة التحكم"] },
    ],
    is_seed_placeholder: true,
  },
];
