/**
 * تنفيذ حقيقي عبر Supabase (Postgres + Auth) — هذا الملف هو "الوجه الحقيقي" لما كان
 * يُحاكى محليًا في store.ts. يُستدعى تلقائيًا فقط عندما isSupabaseConfigured === true
 * (أي بعد إضافة VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY وتشغيل supabase/schema.sql).
 */
import { supabase } from "./supabase";
import { Bird, MigrationWindow } from "../types";
import type { NotificationSettings, LocalProfile, Room, RoomMessage } from "./store";

interface BirdRow {
  id: string;
  name_ar: string;
  name_en: string;
  description: string;
  image_url: string | null;
  season: "spring" | "autumn";
  route: { lat: number; lng: number; label: string }[];
}
interface WindowRow {
  bird_id: string;
  country_code: string;
  start_date: string;
  end_date: string;
  places: string[];
}

function rowsToBirds(birdRows: BirdRow[], windowRows: WindowRow[]): Bird[] {
  return birdRows.map((b) => ({
    id: b.id,
    name_ar: b.name_ar,
    name_en: b.name_en,
    description: b.description,
    image_url: b.image_url,
    season: b.season,
    route: b.route ?? [],
    windows: windowRows
      .filter((w) => w.bird_id === b.id)
      .map<MigrationWindow>((w) => ({
        country: w.country_code as MigrationWindow["country"],
        start_date: w.start_date,
        end_date: w.end_date,
        places: w.places ?? [],
      })),
  }));
}

export async function sbListBirds(): Promise<Bird[]> {
  const [{ data: birdRows, error: e1 }, { data: windowRows, error: e2 }] = await Promise.all([
    supabase.from("birds").select("*"),
    supabase.from("migration_windows").select("*"),
  ]);
  if (e1) throw e1;
  if (e2) throw e2;
  return rowsToBirds((birdRows ?? []) as BirdRow[], (windowRows ?? []) as WindowRow[]);
}

export async function sbGetBird(id: string): Promise<Bird | null> {
  const [{ data: birdRow, error: e1 }, { data: windowRows, error: e2 }] = await Promise.all([
    supabase.from("birds").select("*").eq("id", id).maybeSingle(),
    supabase.from("migration_windows").select("*").eq("bird_id", id),
  ]);
  if (e1) throw e1;
  if (e2) throw e2;
  if (!birdRow) return null;
  return rowsToBirds([birdRow as BirdRow], (windowRows ?? []) as WindowRow[])[0];
}

export async function sbUpsertBird(bird: Bird): Promise<void> {
  const { error: birdErr } = await supabase.from("birds").upsert({
    id: bird.id,
    name_ar: bird.name_ar,
    name_en: bird.name_en,
    description: bird.description,
    image_url: bird.image_url,
    season: bird.season,
    route: bird.route,
    updated_at: new Date().toISOString(),
  });
  if (birdErr) throw birdErr;

  // استبدال مواعيد الهجرة بالكامل لتبسيط التزامن (حذف ثم إدراج)
  const { error: delErr } = await supabase.from("migration_windows").delete().eq("bird_id", bird.id);
  if (delErr) throw delErr;
  if (bird.windows.length > 0) {
    const { error: insErr } = await supabase.from("migration_windows").insert(
      bird.windows.map((w) => ({
        bird_id: bird.id,
        country_code: w.country,
        start_date: w.start_date,
        end_date: w.end_date,
        places: w.places,
      }))
    );
    if (insErr) throw insErr;
  }
}

export async function sbDeleteBird(id: string): Promise<void> {
  const { error } = await supabase.from("birds").delete().eq("id", id);
  if (error) throw error;
}

// ---------------- المفضلة ----------------
export async function sbGetFavoriteIds(userId: string): Promise<string[]> {
  const { data, error } = await supabase.from("favorites").select("bird_id").eq("user_id", userId);
  if (error) throw error;
  return (data ?? []).map((r: { bird_id: string }) => r.bird_id);
}

export async function sbToggleFavorite(userId: string, birdId: string): Promise<string[]> {
  const current = await sbGetFavoriteIds(userId);
  if (current.includes(birdId)) {
    const { error } = await supabase.from("favorites").delete().eq("user_id", userId).eq("bird_id", birdId);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("favorites").insert({ user_id: userId, bird_id: birdId });
    if (error) throw error;
  }
  return sbGetFavoriteIds(userId);
}

// ---------------- إعدادات التنبيهات ----------------
export async function sbGetNotificationSettings(userId: string): Promise<NotificationSettings> {
  const { data, error } = await supabase.from("notification_settings").select("*").eq("user_id", userId).maybeSingle();
  if (error) throw error;
  if (!data) return { enabled: true, daysBefore: 7 };
  return { enabled: data.enabled, daysBefore: data.days_before };
}

export async function sbSetNotificationSettings(userId: string, s: NotificationSettings): Promise<void> {
  const { error } = await supabase
    .from("notification_settings")
    .upsert({ user_id: userId, enabled: s.enabled, days_before: s.daysBefore });
  if (error) throw error;
}

// ---------------- الملف الشخصي ----------------
export async function sbGetProfile(userId: string): Promise<LocalProfile> {
  const { data, error } = await supabase.from("profiles").select("name").eq("id", userId).maybeSingle();
  if (error) throw error;
  return { name: data?.name ?? "مستخدم", userId };
}

export async function sbUpdateProfileName(userId: string, name: string): Promise<void> {
  const { error } = await supabase.from("profiles").update({ name }).eq("id", userId);
  if (error) throw error;
}

// ============================================================
// الرومات + الشات (Supabase Realtime)
// ============================================================

interface RoomRow {
  id: string;
  name: string;
  description: string;
  host_id: string;
  seats_count: 4 | 6 | 8 | 12;
  is_private: boolean;
  password: string | null;
  locked: boolean;
  created_at: string;
}
interface SeatRow {
  room_id: string;
  seat_index: number;
  user_id: string | null;
  muted: boolean;
}
interface MessageRow {
  id: string;
  room_id: string;
  user_id: string;
  text: string;
  created_at: string;
}

// اسم المضيف والمستخدمين يُقرأ من جدول profiles — نجهّز خريطة id→name لتقليل الاستعلامات
async function namesFor(userIds: string[]): Promise<Record<string, string>> {
  const unique = Array.from(new Set(userIds.filter(Boolean)));
  if (unique.length === 0) return {};
  const { data, error } = await supabase.from("profiles").select("id, name").in("id", unique);
  if (error) throw error;
  const map: Record<string, string> = {};
  (data ?? []).forEach((p: { id: string; name: string }) => (map[p.id] = p.name));
  return map;
}

async function roomRowToRoom(r: RoomRow, seats: SeatRow[]): Promise<Room> {
  const names = await namesFor([r.host_id, ...seats.map((s) => s.user_id ?? "")]);
  return {
    id: r.id,
    name: r.name,
    description: r.description,
    hostName: names[r.host_id] ?? "مضيف",
    seatsCount: r.seats_count,
    isPrivate: r.is_private,
    password: r.password,
    locked: r.locked,
    createdAt: r.created_at,
    seats: Array.from({ length: r.seats_count }, (_, i) => {
      const row = seats.find((s) => s.seat_index === i);
      return {
        index: i,
        userId: row?.user_id ?? null,
        userName: row?.user_id ? names[row.user_id] ?? "مستخدم" : null,
        muted: row?.muted ?? true,
      };
    }),
  };
}

export async function sbListRooms(): Promise<Room[]> {
  const { data: rooms, error } = await supabase.from("rooms").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  const { data: seats, error: e2 } = await supabase.from("room_seats").select("*");
  if (e2) throw e2;
  return Promise.all(((rooms ?? []) as RoomRow[]).map((r) => roomRowToRoom(r, (seats ?? []).filter((s: SeatRow) => s.room_id === r.id))));
}

export async function sbGetRoom(id: string): Promise<Room | null> {
  const { data: room, error } = await supabase.from("rooms").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  if (!room) return null;
  const { data: seats, error: e2 } = await supabase.from("room_seats").select("*").eq("room_id", id);
  if (e2) throw e2;
  return roomRowToRoom(room as RoomRow, (seats ?? []) as SeatRow[]);
}

function makeRoomId(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function sbCreateRoom(
  hostId: string,
  input: { name: string; description: string; seatsCount: 4 | 6 | 8 | 12; isPrivate: boolean; password: string | null }
): Promise<Room> {
  const id = makeRoomId();
  const { error: roomErr } = await supabase.from("rooms").insert({
    id,
    name: input.name,
    description: input.description,
    host_id: hostId,
    seats_count: input.seatsCount,
    is_private: input.isPrivate,
    password: input.password,
  });
  if (roomErr) throw roomErr;

  const seatRows = Array.from({ length: input.seatsCount }, (_, i) => ({
    room_id: id,
    seat_index: i,
    user_id: i === 0 ? hostId : null,
    muted: true,
  }));
  const { error: seatsErr } = await supabase.from("room_seats").insert(seatRows);
  if (seatsErr) throw seatsErr;

  return (await sbGetRoom(id))!;
}

export async function sbJoinRoom(roomId: string, userId: string): Promise<Room | null> {
  const room = await sbGetRoom(roomId);
  if (!room) return null;
  const alreadyIn = room.seats.some((s) => s.userId === userId);
  if (!alreadyIn) {
    const freeSeat = room.seats.find((s) => s.userId === null);
    if (freeSeat) {
      const { error } = await supabase
        .from("room_seats")
        .update({ user_id: userId, muted: true })
        .eq("room_id", roomId)
        .eq("seat_index", freeSeat.index)
        .is("user_id", null); // يمنع سباق التزامن (اثنين يحاولان نفس المقعد الفارغ في نفس اللحظة)
      if (error) throw error;
    }
  }
  return sbGetRoom(roomId);
}

export async function sbLeaveRoom(roomId: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from("room_seats")
    .update({ user_id: null, muted: true })
    .eq("room_id", roomId)
    .eq("user_id", userId);
  if (error) throw error;
}

export async function sbSetSeatMuted(roomId: string, userId: string, muted: boolean): Promise<void> {
  const { error } = await supabase.from("room_seats").update({ muted }).eq("room_id", roomId).eq("user_id", userId);
  if (error) throw error;
}

export async function sbDeleteRoom(roomId: string): Promise<void> {
  const { error } = await supabase.from("rooms").delete().eq("id", roomId);
  if (error) throw error;
}

export async function sbGetRoomMessages(roomId: string): Promise<RoomMessage[]> {
  const { data, error } = await supabase
    .from("room_messages")
    .select("*")
    .eq("room_id", roomId)
    .order("created_at", { ascending: true })
    .limit(200);
  if (error) throw error;
  const names = await namesFor(((data ?? []) as MessageRow[]).map((m) => m.user_id));
  return ((data ?? []) as MessageRow[]).map((m) => ({
    id: m.id,
    userName: names[m.user_id] ?? "مستخدم",
    text: m.text,
    time: m.created_at,
  }));
}

export async function sbSendRoomMessage(roomId: string, userId: string, text: string): Promise<void> {
  const { error } = await supabase.from("room_messages").insert({ room_id: roomId, user_id: userId, text });
  if (error) throw error;
}

// اشتراك Realtime حقيقي: يُستدعى callback فورًا عند أي تغيير في مقاعد الغرفة أو رسائلها
export function sbSubscribeToRoom(roomId: string, onChange: () => void) {
  const channel = supabase
    .channel(`room-${roomId}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "room_seats", filter: `room_id=eq.${roomId}` }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "room_messages", filter: `room_id=eq.${roomId}` }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "rooms", filter: `id=eq.${roomId}` }, onChange)
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}

export function sbSubscribeToRoomsList(onChange: () => void) {
  const channel = supabase
    .channel("rooms-list")
    .on("postgres_changes", { event: "*", schema: "public", table: "rooms" }, onChange)
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}
