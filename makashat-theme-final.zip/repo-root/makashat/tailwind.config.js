/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  // حماية صريحة: هذه الفئات حرجة لكل نظام الثيم (المظهر/الألوان) وتُستخدم فعليًا
  // في عشرات الملفات ضمن template literals ديناميكية (مثل isActive ? "text-accent" : ...).
  // الـ safelist يضمن توليدها دائمًا في CSS النهائي بغض النظر عن أي تفاوت في كيفية
  // اكتشاف Tailwind لها أثناء فحص المحتوى — يمنع فئة كاملة من مشاكل "الإعداد لا يتغيّر بصريًا".
  safelist: [
    { pattern: /^(bg|text|border)-(surface-base|surface-raised|surface-card|ink-primary|ink-secondary|ink-muted|accent|accent-soft)(\/\d+)?$/ },
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["Tajawal", "system-ui", "sans-serif"],
        body: ["Cairo", "system-ui", "sans-serif"],
      },
      colors: {
        // كل هذه القيم يتم استبدالها فعليًا وقت التشغيل عبر CSS variables
        // (انظر src/styles/theme.css) حتى يعمل تغيير اللون بدون إعادة تشغيل
        surface: {
          base: "rgb(var(--c-surface-base) / <alpha-value>)",
          raised: "rgb(var(--c-surface-raised) / <alpha-value>)",
          card: "rgb(var(--c-surface-card) / <alpha-value>)",
        },
        accent: {
          DEFAULT: "rgb(var(--c-accent) / <alpha-value>)",
          soft: "rgb(var(--c-accent-soft) / <alpha-value>)",
        },
        ink: {
          primary: "rgb(var(--c-ink-primary) / <alpha-value>)",
          secondary: "rgb(var(--c-ink-secondary) / <alpha-value>)",
          muted: "rgb(var(--c-ink-muted) / <alpha-value>)",
        },
      },
      borderRadius: {
        card: "20px",
        pill: "999px",
      },
      transitionDuration: {
        press: "180ms",
      },
    },
  },
  plugins: [],
};
