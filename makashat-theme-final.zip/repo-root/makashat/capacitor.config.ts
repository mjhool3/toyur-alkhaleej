import { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.makashat.app",
  appName: "مكشات",
  webDir: "dist",
  server: { androidScheme: "https" },
};

export default config;
